# Machine-Translation-Hindi-to-english-

Attention in NLP can be understood from the following sources:- 

1) https://medium.com/syncedreview/a-brief-overview-of-attention-mechanism-13c578ba9129
2) https://medium.com/@joealato/attention-in-nlp-734c6fa9d983
